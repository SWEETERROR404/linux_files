#!/data/data/com.termux/files/usr/bin/bash
cd $(dirname $0)
## unset LD_PRELOAD in case termux-exec is installed
unset LD_PRELOAD
command="proot"
command+=" --link2symlink"
command+=" -0"
#command+=" -r ../../rinix-fs/debian/debian-fs"
command+=" -r $RINIX_RFS"

if [ -n "$(ls -A debian-binds)" ]; then
    for f in debian-binds/* ;do
      . $f
    done
fi
command+=" -b /dev"
command+=" -b /proc"
command+=" -b ../dec/root/orc:/root/orc"
command+=" -b ../dec/user/orc:/home/$RINIX_RDU/orc"
command+=" -b /proc"
#command+=" -b ../../rinix-fs/debian/debian-fs/root:/dev/shm"
command+=" -b $RINIX_RFS:/dev/shm"

command+=" -b /sdcard:/home/$RINIX_RDU/sdcard"
command+=" -b /sdcard/AWN:/home/$RINIX_RDU/AWN"
command+=" -b $HOME:/home/$RINIX_RDU/shared/termux"

command+=" -b /data -b /data/dalvik-cache/ -b /system/ -b /data/data/com.termux/files/usr/ -b /property_contexts -b /vendor"

## uncomment the following line to have access to the home directory of termux
#command+=" -b /data/data/com.termux/files/home:/root"
## uncomment the following line to mount /sdcard directly to / 
#command+=" -b /sdcard"
command+=" -w /root"
command+=" /usr/bin/env -i"
command+=" HOME=/root"
#command+=" ANDROID_DATA=/data"
command+=" PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games"
command+=" TERM=$TERM"
command+=" LANG=C.UTF-8"
command+=" sh orc/orc $1"
#/bin/bash --login"
com="$@"
if [ -z "$1" ];then
    exec $command
else
#    $command -c "$com"
	exec $command
fi
